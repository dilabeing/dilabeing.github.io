<?php
/**
 * This file just still exists because of compatibility-reasons.
 * 
 * All classes are located now in the "libs"-folder!
 */
$current_path = dirname(__FILE__);
include_once($current_path."/../libs/PHPCrawler.class.php");
?>